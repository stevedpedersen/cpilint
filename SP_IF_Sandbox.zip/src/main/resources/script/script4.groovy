import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

def Message processData(Message message) {
    def sb_text = new StringBuilder()
    def body = message.getBody()
    def infomap = new HashMap()
    def attachments = message.getAttachments()
    if ((attachments != null) && (!attachments.isEmpty())) {
        infomap.put("attachments", attachments)
        infomap.put("attachments.clazz.name", attachments.getClass().getName())
        infomap.put("attachments.keys", attachments.getOriginalMap().keySet())
        attachments.each { key -> infomap.put("attachments[" + key.getKey() + "]", attachments.get(key.getKey())) }
        dumpProperties_TEXT("Attachments", infomap, sb_text)
    }
    
    def bodymap = new HashMap()
    if (body instanceof String) {
        if (body.size() > 100) {
            bodymap.put("Body", body.substring(0, 100) + "...")
        } else {
            bodymap.put("Body", body)
        }
    } else {
        bodymap.put("Body", body)
    }
    if (body != null) {
        bodymap.put("body.clazz.name", body.getClass().getCanonicalName())
    }
    dumpProperties_TEXT("Body", bodymap, sb_text)

    message.setBody("${body.toString()}\n\n" + sb_text.toString())
    message.setHeader("Content-Type", "text/plain")
    message
}

void dumpProperties_TEXT(String title, Map<String, Object> map, StringBuilder sb) {
    sb.append(title + "\n")
    map.each { key, value ->
        sb.append(String.format(" %-40s: %-40s\n", key, value))
    }
    sb.append("\n")
}