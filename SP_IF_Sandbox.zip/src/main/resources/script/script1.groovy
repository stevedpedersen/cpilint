import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonBuilder
import org.apache.camel.*
import org.apache.camel.spi.RouteController
import org.osgi.framework.*
// import com.sap.gateway.ip.core.customdev.util.SoapHeader

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    def isError = "S"
    // message.removeProperty("a_ok")
    def ex = message.getProperty("CamelExceptionCaught")
    if (ex != null) {
        isError = "E"
        def stepId = message.getProperty("SAP_ErrorModelStepID")
        def errorMsg = "SAP_ErrorModelStepID: ${stepId}\n"
        errorMsg += ex?.getLocalizedMessage() ? "Localized MSG: ${ex.getLocalizedMessage()}\n" : ""
        errorMsg += ex?.getLocalizedMessage() ? "EXC MSG: ${ex.getMessage()}\n" : ""
        messageLog.addAttachmentAsString("Error Msg ${isError}", errorMsg, "text/plain")
    }
    
    Exchange exchange = message.exchange
    try {
        exchange.removeProperty("a_ok")
    } catch (Exception e) {
        
    }

//     def iFlow = "SP_IF_Sandbox"
// 	def bundleCtx = FrameworkUtil.getBundle(Class.forName("com.sap.gateway.ip.core.customdev.util.Message")).getBundleContext()
// 	ServiceReference[] srs = bundleCtx.getServiceReferences(CamelContext.class.getName(), "(camel.context.name=${iFlow})");
// 	CamelContext camelContext = (CamelContext)bundleCtx.getService(srs[0])
	

//     def results = ""
//     List<MessageHistory> list = exchange.getProperty(Exchange.MESSAGE_HISTORY, List.class);
//     for (MessageHistory history : list) {
//         results += "Routed at id: " + history.getNode().getId() + "\n"
//     }
//     messageLog.addAttachmentAsString("Route IDs ${isError}", results, "text/plain")
    
    
//     def other = "IS TRANSACTED:\t ${exchange.isTransacted().toString()}\n"
//         other += "EXCHANGE ID:\t ${exchange.getExchangeId()}\n"
//         other += "FROM ROUTE ID:\t ${exchange.getFromRouteId()}\n"
//         other += "IS MESSAGE HISTORY:\t ${camelContext.isMessageHistory()}\n"
//         // other += "IS DEBUGGING:\t ${camelContext.isDebugging()}\n"
//         // other += "IS DEV CONSOLE:\t ${camelContext.isDevConsole()}\n"
//     // exchange.setExchangeId("123456789")
//     // other += "EXCHANGE ID:\t ${exchange.getExchangeId()}\n"
//     messageLog.addAttachmentAsString("Other ${isError}", other, "text/plain")
    
    return message;
}