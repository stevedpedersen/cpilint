import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.securestore.UserCredential
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.exception.SecureStoreException
import com.sap.it.api.keystore.KeystoreService
import com.sap.it.api.ITApiFactory
import groovy.json.JsonBuilder

def Message processData(Message msg) {
    processSecrets(msg, false)
}
def Message includeKeystore(Message msg) {
    processSecrets(msg, true)
}

def Message processSecrets(Message msg, boolean includeKeystore = false) {
    def outputFormat = msg.headers["Output-Format"] // Header to obtain output format
    def results = collectResults(msg, includeKeystore)
    
    // Convert results to JSON if specified
    def output
    if (outputFormat == "json") {
        if (!includeKeystore) { 
            output = new JsonBuilder(results).toPrettyString() 
        } else {
            output = new JsonBuilder(results).toJson()
        }
        msg.setHeader("Content-Type", "application/json")
    } else {
        output = formatResults(results) // Format results for plain text output
        msg.setHeader("Content-Type", "text/plain")
    }
    msg.setBody(output)
    msg
}

def Map collectResults(Message msg, boolean includeKeystore) {
    def results = [
        summary: [:], // Initialize summary field
        userCredentials: [], // Ensure this is initialized as an empty list
        secureParameters: [], // Ensure this is initialized as an empty list
        secureStoreInfo: [:], // Initialize as an empty map
        keystoreInfo: includeKeystore ? [:] : null, // Initialize based on includeKeystore
    ]

    try {
        if (isInvalidRequest(msg, results)) return results
        
        SecureStoreService sss = ITApiFactory.getApi(SecureStoreService.class, null)

        if (msg.headers.Credentials) {
            def creds = msg.headers.Credentials.split(",") ?: []
            creds.each {  
                try {
                    UserCredential uc = sss.getUserCredential(it as String)
                    // Check the type of credential and categorize
                    def credentialKind = uc.credentialProperties['sec:credential.kind']
                    if (credentialKind == 'secure_param') {
                        results.secureParameters << [
                            username: uc.username ?: 'N/A',
                            properties: uc.credentialProperties ?: [:],
                            password: "${uc.password?.toString() ?: ''}" ?: 'N/A'
                        ]
                    } else {
                        results.userCredentials << [
                            username: uc.username ?: 'N/A',
                            properties: uc.credentialProperties ?: [:],
                            password: "${uc.password?.toString() ?: ''}" ?: 'N/A'
                        ]
                    }
                } catch (SecureStoreException e) {
                    results.userCredentials << [error: "Error retrieving UserCredential for: $it - ${e.message}"]
                }
            }
        }

        // Collect Secure Store information
        results.secureStoreInfo.securityStoreType = sss.getClass().getName()
        try { results.secureStoreInfo.keyManager = sss.keyManagers } catch (Exception ignored) {}
        try { results.secureStoreInfo.trustManager = sss.trustManager } catch (Exception ignored) {}

        // Collect Keystore information if specified
        if (includeKeystore) {
            KeystoreService ks = ITApiFactory.getApi(KeystoreService.class, null)
            results.keystoreInfo.keyStoreType = ks.getClass().getName()
            try { 
                results.keystoreInfo.keyManagers = ks.keyManagers ?: [] // Ensure list initialization
            } catch (Exception ignored) {}
            try { 
                results.keystoreInfo.trustManagers = ks.trustManagers ?: [] // Ensure list initialization
            } catch (Exception ignored) {}
        }

        // Calculate totals for summary
        results.summary.totalUserCredentials = results.userCredentials.size()
        results.summary.totalSecureParameters = results.secureParameters.size()
        results.summary.totalKeystoreItems = includeKeystore ? (results.keystoreInfo?.keyManagers?.size() ?: 0) : 0
        results.summary.keystoreIncluded = includeKeystore ? "Yes" : "No"

    } catch (SecureStoreException se) {
        results.error = "Error in collectResults: ${se.message}"
    }

    return results
}

def String credentialApi(Message msg) {
    def log = new StringBuilder()
    try {
        if (isInvalidRequest(msg, log)) return log.toString()
        
        SecureStoreService sss = ITApiFactory.getApi(SecureStoreService.class, null)
        if (msg.headers.Credentials) {
            def creds = msg.headers.Credentials.split(",") ?: []
            log << "\n\nmsg.headers.Credentials.split(,).size(): ${creds.size()}" 
            creds.each {  
                try {
                    UserCredential uc = sss.getUserCredential(it as String)
                    log << "\ncom.sap.it.api.securestore.UserCredential:\t$uc"
                    log << "\nUserCredential properties:\t${uc.credentialProperties ?: 'N/A'}"
                    log << "\nUserCredential username:\t${uc.username ?: 'N/A'}"
                    log << "\nUserCredential password:\t${uc.password ?: 'N/A'}"
                } catch (SecureStoreException e) {
                    log << "\nError retrieving UserCredential for: $it - ${e.message}"
                }
            }
            log << "\n"
        }
    } catch (SecureStoreException se) {
        log << "\nError in credentialApi: ${se.message}"
    }
    log.toString()
}

def String credentialApiReflection(Message msg) {
    def log = new StringBuilder()
    try {
        if (isInvalidRequest(msg, log)) return log.toString()
        
        // Similar reflection logic
        Class secureStoreService = Class.forName("com.sap.it.api.securestore.SecureStoreService")
        Class keystoreService = Class.forName("com.sap.it.api.keystore.KeystoreService")
        Class userCredential = Class.forName("com.sap.it.api.securestore.UserCredential")
        
        log << "\nclass com.sap.it.api.securestore.SecureStoreService:\t$secureStoreService"
        log << "\nclass com.sap.it.api.keystore.KeystoreService:\t$keystoreService"
        log << "\nclass com.sap.it.api.securestore.UserCredential:\t$userCredential"

        def sss =  ITApiFactory.getApi(SecureStoreService.class, null)
        log << "\ncom.sap.it.api.securestore.SecureStoreService:\t$sss"
        if (msg.headers.Credentials) {
            def creds = msg.headers.Credentials.split(",")
            log << "\n\nmsg.headers.Credentials.split(,).size(): ${creds.size()}" 
            creds.each {  
                try {
                    UserCredential uc = sss.getUserCredential(it as String)
                    log << "\ncom.sap.it.api.securestore.UserCredential:\t$uc"
                    log << "\nUserCredential properties:\t${uc.credentialProperties ?: 'N/A'}"
                    log << "\nUserCredential username:\t${uc.username ?: 'N/A'}"
                    log << "\nUserCredential password:\t${uc.password ?: 'N/A'}"
                } catch (SecureStoreException e) {
                    log << "\nError retrieving UserCredential for: $it - ${e.message}"
                }
            }
        }
    } catch (SecureStoreException se) {
        log << "\nError in credentialApiReflection: ${se.message}"
    }
    log.toString()                               
}

def boolean isInvalidRequest(Message msg, def log) {
    if (!msg.headers.Credentials && !msg.headers.Keystore) {
        log << "\n\nError - Missing one of the required Headers:\n"
        log << "\nHeader `Credentials` - got value  `${msg.headers.Credentials ?: 'N/A'}`." 
        log << "\nHeader `Keystore` - got value  `${msg.headers.Keystore ?: 'N/A'}`"
        log << "\n"
        msg.setHeader("CamelHttpCode", "404")
        msg.setBody(log.toString())
        return true
    }
    return false
}

def String formatResults(Map results) {
    def sb = new StringBuilder()
    results.each { key, value ->
        sb.append("\n\n\t-----\t${key}\t-----\n${value}\n")
    }
    sb.toString()
}

def String styledBreak(int index = 0) {
    ["\uff21\uff22\uff23", "\u24F5\u24F6\u24F7"][index]
}

// import com.sap.gateway.ip.core.customdev.util.Message
// import com.sap.it.api.securestore.UserCredential
// import com.sap.it.api.securestore.SecureStoreService
// import com.sap.it.api.keystore.KeystoreService
// import com.sap.it.api.ITApiFactory

// def Message processData(Message message) {
//     def resultApi = credentialApi(message)
//     def resultReflect = credentialApiReflection(message)
//     def results = new StringBuilder()
//     results << "\n\n\t-----\tAPI Results\t-----\n${resultApi}\n" 
//     results << styledBreak(1)
//     results << "\n\n\t-----\tAPI Reflection Results\t-----\n${resultReflect}\n"
//     message.setBody(results.toString() as String)
//     message.setHeader("Content-Type", "text/plain")
//     message
// }

// def String credentialApi(Message msg) {
// 	def log = new StringBuilder()
// 	if (isInvalidRequest(msg, log)) return log.toString()
	
// 	SecureStoreService sss = ITApiFactory.getApi(SecureStoreService.class, null)
//     if (msg.headers.Credentials) {
//         def creds = msg.headers.Credentials.split(",") ?: []
//         log << "\n\nmsg.headers.Credentials.split(,).size(): ${creds.size()}" 
//         creds.each {  
//             com.sap.it.api.securestore.UserCredential uc = sss.getUserCredential(it as String)
//             log << "\ncom.sap.it.api.securestore.UserCredential:\t$uc"
//             log << "\nUserCredential properties:\t${uc.credentialProperties}"
//             log << "\nUserCredential username:\t${uc.username}"
//             log << "\nUserCredential password:\t${uc.password}"
//         }
//         log << "\n"//styledBreak(0)
//     }

// 	com.sap.it.api.keystore.KeystoreService ks = ITApiFactory.getApi(com.sap.it.api.keystore.KeystoreService.class, null)
// 	log << "\n\ncom.sap.it.api.keystore.KeystoreService:\t$ks"
// 	log << "\ncom.sap.it.api.keystore.KeystoreService javax.net.ssl.KeyManager:\t${ks.keyManager}"
// 	log << "\ncom.sap.it.api.keystore.KeystoreService javax.net.ssl.KeyManagers:\t${ks.keyManagers}"
// 	log << "\ncom.sap.it.api.keystore.KeystoreService javax.net.ssl.TrustManager:\t${ks.trustManager}"
// 	log << "\ncom.sap.it.api.keystore.KeystoreService javax.net.ssl.TrustManagers:\t${ks.trustManagers}"
	
// 	if (msg.headers.Keystore) {
// 		log << "\n\nKeystore: $msg.headers.Keystore\n"
// 		// log << styledBreak(0)
// 	}
// 	log.toString()                              
// }

// def String credentialApiReflection(Message msg) {
// 	def log = new StringBuilder()
// 	if (isInvalidRequest(msg, log)) return log.toString()
	
//     // Class itApiFactory = Class.forName("com.sap.it.api.ITApiFactory.ITApiFactory")
// 	Class secureStoreService = Class.forName("com.sap.it.api.securestore.SecureStoreService")
// 	Class keystoreService = Class.forName("com.sap.it.api.keystore.KeystoreService")
// 	Class userCredential = Class.forName("com.sap.it.api.securestore.UserCredential")
	
// // 	log << "\nclass ITApiFactory:\t$itApiFactory"
// 	log << "\nclass com.sap.it.api.securestore.SecureStoreService:\t$secureStoreService"
// 	log << "\nclass com.sap.it.api.keystore.KeystoreService:\t$keystoreService"
// 	log << "\nclass com.sap.it.api.securestore.UserCredential:\t$userCredential"

// 	def sss =  ITApiFactory.getApi(SecureStoreService.class, null)
// 	log << "\ncom.sap.it.api.securestore.SecureStoreService:\t$sss"
// 	if (msg.headers.Credentials) {
//         def creds = msg.headers.Credentials.split(",")
//         log << "\n\nmsg.headers.Credentials.split(,).size(): ${creds.size()}" 
//         creds.each {  
//             com.sap.it.api.securestore.UserCredential uc = sss.getUserCredential(it as String)
//             log << "\ncom.sap.it.api.securestore.UserCredential:\t$uc"
//             log << "\nUserCredential properties:\t${uc.credentialProperties}"
//             log << "\nUserCredential username:\t${uc.username}"
//             log << "\nUserCredential password:\t${uc.password}"
//         }
// 	}
// 	log.toString()                               
// }

// def boolean isInvalidRequest(Message msg, def log) {
// 	if (!msg.headers.Credentials && !msg.headers.Keystore) {
// 		log << "\n\nError - Missing one of the required Headers:\n"
// 		log << "\nHeader `Credentials` - got value  `${msg.headers.Credentials}`." 
// 		log << "\nHeader `Keystore` - got value  `${msg.headers.Keystore}"
// 		log << "\n"//styledBreak(1)
// 		msg.setHeader("CamelHttpCode", "404")
// 		msg.setBody(log.toString())
// 		return true
// 	}
// 	return false
// }

// def String styledBreak(int index = 0) {
//     ["\uff21\uff22\uff23", "\u24F5\u24F6\u24F7"][index]
// }

// // def String styledBreak(int index = 0) {
// // 	def unicodes = ["\uff21\uff22\uff23\uff24\uff25\uff26\uff27\uff28\uff29\uff2a\uff2b\uff2c\uff2d\uff2e\uff2f\uff30\uff31\uff32\uff33\uff34\uff35\uff36\uff37\uff38\uff39\uff3a",
// // 		"\u24F5\u24F6\u24F7\u24F8\u24F9\u24FA\u24FB\u24FC\u24FD\u24FE\u277F\u2780\u2781\u2782\u2783\u2784\u2785\u2786\u2787\u2788\u2789\u278A\u278B\u278C\u278D\u278E\u278F\u2790\u2791\u2792\u2793"][index]
// //     def unicodeSplit = unicodes.split("")
// //     def charCount = unicodeSplit.size()
// //     def increment = 1//2 - charCount % 2 
// //     def unit = charCount > 0 ? 3 : 0
// //     def scalar = (charCount % 3 == 0 ? 3 : 2)  
// //     def log = new StringBuilder()
// //     i = 0
// //     while (i < charCount - 1) {
// //         log << "${unicodeSplit[i]}${unicodeSplit[i + 1]}"
// //         log << (i > 1 && i % 18 == 0 ? "\n" : "")
// //         i += 1
// //     }
// //     log.toString()
// // }

// // def String getCat(String key) {
// //     def cats = [:]
// // 	cats.Cc = "\u0000\u0001\u0002\u0003\u0004\u0005\u0006\u0007\u0008\t\n\u000b\u000c\u000e\u000f\u0010\u0011\u0012\u0013\u0014\u0015\u0016\u0017\u0018\u0019\u001a\u001b\u001c\u001d\u001e\u001f\u007f\u0080\u0081\u0082\u0083\u0084\u0085\u0086\u0087\u0088\u0089\u008a\u008b\u008c\u008d\u008e\u008f\u0090\u0091\u0092\u0093\u0094\u0095\u0096\u0097\u0098\u0099\u009a\u009b\u009c\u009d\u009e\u009f"

// // 	cats.Cf = "\u00ad\u0600\u0601\u0602\u0603\u06dd\u070f\u17b4\u17b5\u200b\u200c\u200d\u200e\u200f\u202a\u202b\u202c\u202d\u202e\u2060\u2061\u2062\u2063\u206a\u206b\u206c\u206d\u206e\u206f\ufeff\ufff9\ufffa\ufffb"

// // 	// abcdefghijklmnopqrstuvwxyz
// // 	cats.Ll = "\u00aa\u00b5\u00ba\u00df\u00e0\u00e1\u00e2\u00e3\u00e4\u00e5\u00e6\u00e7\u00e8\u00e9\u00ea\u00eb\u00ec\u00ed\u00ee\u00ef\u00f0\u00f1\u00f2\u00f3\u00f4\u00f5\u00f6\u00f8\u00f9\u00fa\u00fb\u00fc\u00fd\u00fe\u00ff\u0101\u0103\u0105\u0107\u0109\u010b\u010d\u010f\u0111\u0113\u0115\u0117\u0119\u011b\u011d\u011f\u0121\u0123\u0125\u0127\u0129\u012b\u012d\u012f\u0131\u0133\u0135\u0137\u0138\u013a\u013c\u013e\u0140\u0142\u0144\u0146\u0148\u0149\u014b\u014d\u014f\u0151\u0153\u0155\u0157\u0159\u015b\u015d\u015f\u0161\u0163\u0165\u0167\u0169\u016b\u016d\u016f\u0171\u0173\u0175\u0177\u017a\u017c\u017e\u017f\u0180\u0183\u0185\u0188\u018c\u018d\u0192\u0195\u0199\u019a\u019b\u019e\u01a1\u01a3\u01a5\u01a8\u01aa\u01ab\u01ad\u01b0\u01b4\u01b6\u01b9\u01ba\u01bd\u01be\u01bf\u01c6\u01c9\u01cc\u01ce\u01d0\u01d2\u01d4\u01d6\u01d8\u01da\u01dc\u01dd\u01df\u01e1\u01e3\u01e5\u01e7\u01e9\u01eb\u01ed\u01ef\u01f0\u01f3\u01f5\u01f9\u01fb\u01fd\u01ff\u0201\u0203\u0205\u0207\u0209\u020b\u020d\u020f\u0211\u0213\u0215\u0217\u0219\u021b\u021d\u021f\u0221\u0223\u0225\u0227\u0229\u022b\u022d\u022f\u0231\u0233\u0234\u0235\u0236\u0237\u0238\u0239\u023c\u023f\u0240\u0250\u0251\u0252\u0253\u0254\u0255\u0256\u0257\u0258\u0259\u025a\u025b\u025c\u025d\u025e\u025f\u0260\u0261\u0262\u0263\u0264\u0265\u0266\u0267\u0268\u0269\u026a\u026b\u026c\u026d\u026e\u026f\u0270\u0271\u0272\u0273\u0274\u0275\u0276\u0277\u0278\u0279\u027a\u027b\u027c\u027d\u027e\u027f\u0280\u0281\u0282\u0283\u0284\u0285\u0286\u0287\u0288\u0289\u028a\u028b\u028c\u028d\u028e\u028f\u0290\u0291\u0292\u0293\u0294\u0295\u0296\u0297\u0298\u0299\u029a\u029b\u029c\u029d\u029e\u029f\u02a0\u02a1\u02a2\u02a3\u02a4\u02a5\u02a6\u02a7\u02a8\u02a9\u02aa\u02ab\u02ac\u02ad\u02ae\u02af\u0390\u03ac\u03ad\u03ae\u03af\u03b0\u03b1\u03b2\u03b3\u03b4\u03b5\u03b6\u03b7\u03b8\u03b9\u03ba\u03bb\u03bc\u03bd\u03be\u03bf\u03c0\u03c1\u03c2\u03c3\u03c4\u03c5\u03c6\u03c7\u03c8\u03c9\u03ca\u03cb\u03cc\u03cd\u03ce\u03d0\u03d1\u03d5\u03d6\u03d7\u03d9\u03db\u03dd\u03df\u03e1\u03e3\u03e5\u03e7\u03e9\u03eb\u03ed\u03ef\u03f0\u03f1\u03f2\u03f3\u03f5\u03f8\u03fb\u03fc\u0430\u0431\u0432\u0433\u0434\u0435\u0436\u0437\u0438\u0439\u043a\u043b\u043c\u043d\u043e\u043f\u0440\u0441\u0442\u0443\u0444\u0445\u0446\u0447\u0448\u0449\u044a\u044b\u044c\u044d\u044e\u044f\u0450\u0451\u0452\u0453\u0454\u0455\u0456\u0457\u0458\u0459\u045a\u045b\u045c\u045d\u045e\u045f\u0461\u0463\u0465\u0467\u0469\u046b\u046d\u046f\u0471\u0473\u0475\u0477\u0479\u047b\u047d\u047f\u0481\u048b\u048d\u048f\u0491\u0493\u0495\u0497\u0499\u049b\u049d\u049f\u04a1\u04a3\u04a5\u04a7\u04a9\u04ab\u04ad\u04af\u04b1\u04b3\u04b5\u04b7\u04b9\u04bb\u04bd\u04bf\u04c2\u04c4\u04c6\u04c8\u04ca\u04cc\u04ce\u04d1\u04d3\u04d5\u04d7\u04d9\u04db\u04dd\u04df\u04e1\u04e3\u04e5\u04e7\u04e9\u04eb\u04ed\u04ef\u04f1\u04f3\u04f5\u04f7\u04f9\u0501\u0503\u0505\u0507\u0509\u050b\u050d\u050f\u0561\u0562\u0563\u0564\u0565\u0566\u0567\u0568\u0569\u056a\u056b\u056c\u056d\u056e\u056f\u0570\u0571\u0572\u0573\u0574\u0575\u0576\u0577\u0578\u0579\u057a\u057b\u057c\u057d\u057e\u057f\u0580\u0581\u0582\u0583\u0584\u0585\u0586\u0587\u1d00\u1d01\u1d02\u1d03\u1d04\u1d05\u1d06\u1d07\u1d08\u1d09\u1d0a\u1d0b\u1d0c\u1d0d\u1d0e\u1d0f\u1d10\u1d11\u1d12\u1d13\u1d14\u1d15\u1d16\u1d17\u1d18\u1d19\u1d1a\u1d1b\u1d1c\u1d1d\u1d1e\u1d1f\u1d20\u1d21\u1d22\u1d23\u1d24\u1d25\u1d26\u1d27\u1d28\u1d29\u1d2a\u1d2b\u1d62\u1d63\u1d64\u1d65\u1d66\u1d67\u1d68\u1d69\u1d6a\u1d6b\u1d6c\u1d6d\u1d6e\u1d6f\u1d70\u1d71\u1d72\u1d73\u1d74\u1d75\u1d76\u1d77\u1d79\u1d7a\u1d7b\u1d7c\u1d7d\u1d7e\u1d7f\u1d80\u1d81\u1d82\u1d83\u1d84\u1d85\u1d86\u1d87\u1d88\u1d89\u1d8a\u1d8b\u1d8c\u1d8d\u1d8e\u1d8f\u1d90\u1d91\u1d92\u1d93\u1d94\u1d95\u1d96\u1d97\u1d98\u1d99\u1d9a\u1e01\u1e03\u1e05\u1e07\u1e09\u1e0b\u1e0d\u1e0f\u1e11\u1e13\u1e15\u1e17\u1e19\u1e1b\u1e1d\u1e1f\u1e21\u1e23\u1e25\u1e27\u1e29\u1e2b\u1e2d\u1e2f\u1e31\u1e33\u1e35\u1e37\u1e39\u1e3b\u1e3d\u1e3f\u1e41\u1e43\u1e45\u1e47\u1e49\u1e4b\u1e4d\u1e4f\u1e51\u1e53\u1e55\u1e57\u1e59\u1e5b\u1e5d\u1e5f\u1e61\u1e63\u1e65\u1e67\u1e69\u1e6b\u1e6d\u1e6f\u1e71\u1e73\u1e75\u1e77\u1e79\u1e7b\u1e7d\u1e7f\u1e81\u1e83\u1e85\u1e87\u1e89\u1e8b\u1e8d\u1e8f\u1e91\u1e93\u1e95\u1e96\u1e97\u1e98\u1e99\u1e9a\u1e9b\u1ea1\u1ea3\u1ea5\u1ea7\u1ea9\u1eab\u1ead\u1eaf\u1eb1\u1eb3\u1eb5\u1eb7\u1eb9\u1ebb\u1ebd\u1ebf\u1ec1\u1ec3\u1ec5\u1ec7\u1ec9\u1ecb\u1ecd\u1ecf\u1ed1\u1ed3\u1ed5\u1ed7\u1ed9\u1edb\u1edd\u1edf\u1ee1\u1ee3\u1ee5\u1ee7\u1ee9\u1eeb\u1eed\u1eef\u1ef1\u1ef3\u1ef5\u1ef7\u1ef9\u1f00\u1f01\u1f02\u1f03\u1f04\u1f05\u1f06\u1f07\u1f10\u1f11\u1f12\u1f13\u1f14\u1f15\u1f20\u1f21\u1f22\u1f23\u1f24\u1f25\u1f26\u1f27\u1f30\u1f31\u1f32\u1f33\u1f34\u1f35\u1f36\u1f37\u1f40\u1f41\u1f42\u1f43\u1f44\u1f45\u1f50\u1f51\u1f52\u1f53\u1f54\u1f55\u1f56\u1f57\u1f60\u1f61\u1f62\u1f63\u1f64\u1f65\u1f66\u1f67\u1f70\u1f71\u1f72\u1f73\u1f74\u1f75\u1f76\u1f77\u1f78\u1f79\u1f7a\u1f7b\u1f7c\u1f7d\u1f80\u1f81\u1f82\u1f83\u1f84\u1f85\u1f86\u1f87\u1f90\u1f91\u1f92\u1f93\u1f94\u1f95\u1f96\u1f97\u1fa0\u1fa1\u1fa2\u1fa3\u1fa4\u1fa5\u1fa6\u1fa7\u1fb0\u1fb1\u1fb2\u1fb3\u1fb4\u1fb6\u1fb7\u1fbe\u1fc2\u1fc3\u1fc4\u1fc6\u1fc7\u1fd0\u1fd1\u1fd2\u1fd3\u1fd6\u1fd7\u1fe0\u1fe1\u1fe2\u1fe3\u1fe4\u1fe5\u1fe6\u1fe7\u1ff2\u1ff3\u1ff4\u1ff6\u1ff7\u2071\u207f\u210a\u210e\u210f\u2113\u212f\u2134\u2139\u213c\u213d\u2146\u2147\u2148\u2149\u2c30\u2c31\u2c32\u2c33\u2c34\u2c35\u2c36\u2c37\u2c38\u2c39\u2c3a\u2c3b\u2c3c\u2c3d\u2c3e\u2c3f\u2c40\u2c41\u2c42\u2c43\u2c44\u2c45\u2c46\u2c47\u2c48\u2c49\u2c4a\u2c4b\u2c4c\u2c4d\u2c4e\u2c4f\u2c50\u2c51\u2c52\u2c53\u2c54\u2c55\u2c56\u2c57\u2c58\u2c59\u2c5a\u2c5b\u2c5c\u2c5d\u2c5e\u2c81\u2c83\u2c85\u2c87\u2c89\u2c8b\u2c8d\u2c8f\u2c91\u2c93\u2c95\u2c97\u2c99\u2c9b\u2c9d\u2c9f\u2ca1\u2ca3\u2ca5\u2ca7\u2ca9\u2cab\u2cad\u2caf\u2cb1\u2cb3\u2cb5\u2cb7\u2cb9\u2cbb\u2cbd\u2cbf\u2cc1\u2cc3\u2cc5\u2cc7\u2cc9\u2ccb\u2ccd\u2ccf\u2cd1\u2cd3\u2cd5\u2cd7\u2cd9\u2cdb\u2cdd\u2cdf\u2ce1\u2ce3\u2ce4\u2d00\u2d01\u2d02\u2d03\u2d04\u2d05\u2d06\u2d07\u2d08\u2d09\u2d0a\u2d0b\u2d0c\u2d0d\u2d0e\u2d0f\u2d10\u2d11\u2d12\u2d13\u2d14\u2d15\u2d16\u2d17\u2d18\u2d19\u2d1a\u2d1b\u2d1c\u2d1d\u2d1e\u2d1f\u2d20\u2d21\u2d22\u2d23\u2d24\u2d25\ufb00\ufb01\ufb02\ufb03\ufb04\ufb05\ufb06\ufb13\ufb14\ufb15\ufb16\ufb17\uff41\uff42\uff43\uff44\uff45\uff46\uff47\uff48\uff49\uff4a\uff4b\uff4c\uff4d\uff4e\uff4f\uff50\uff51\uff52\uff53\uff54\uff55\uff56\uff57\uff58\uff59\uff5a"

// // 	cats.Lm = "\u02b0\u02b1\u02b2\u02b3\u02b4\u02b5\u02b6\u02b7\u02b8\u02b9\u02ba\u02bb\u02bc\u02bd\u02be\u02bf\u02c0\u02c1\u02c6\u02c7\u02c8\u02c9\u02ca\u02cb\u02cc\u02cd\u02ce\u02cf\u02d0\u02d1\u02e0\u02e1\u02e2\u02e3\u02e4\u02ee\u037a\u0559\u0640\u06e5\u06e6\u0e46\u0ec6\u10fc\u17d7\u1843\u1d2c\u1d2d\u1d2e\u1d2f\u1d30\u1d31\u1d32\u1d33\u1d34\u1d35\u1d36\u1d37\u1d38\u1d39\u1d3a\u1d3b\u1d3c\u1d3d\u1d3e\u1d3f\u1d40\u1d41\u1d42\u1d43\u1d44\u1d45\u1d46\u1d47\u1d48\u1d49\u1d4a\u1d4b\u1d4c\u1d4d\u1d4e\u1d4f\u1d50\u1d51\u1d52\u1d53\u1d54\u1d55\u1d56\u1d57\u1d58\u1d59\u1d5a\u1d5b\u1d5c\u1d5d\u1d5e\u1d5f\u1d60\u1d61\u1d78\u1d9b\u1d9c\u1d9d\u1d9e\u1d9f\u1da0\u1da1\u1da2\u1da3\u1da4\u1da5\u1da6\u1da7\u1da8\u1da9\u1daa\u1dab\u1dac\u1dad\u1dae\u1daf\u1db0\u1db1\u1db2\u1db3\u1db4\u1db5\u1db6\u1db7\u1db8\u1db9\u1dba\u1dbb\u1dbc\u1dbd\u1dbe\u1dbf\u2090\u2091\u2092\u2093\u2094\u2d6f\u3005\u3031\u3032\u3033\u3034\u3035\u303b\u309d\u309e\u30fc\u30fd\u30fe\ua015\uff70\uff9e\uff9f"

// // 	cats.Lt = "\u01c5\u01c8\u01cb\u01f2\u1f88\u1f89\u1f8a\u1f8b\u1f8c\u1f8d\u1f8e\u1f8f\u1f98\u1f99\u1f9a\u1f9b\u1f9c\u1f9d\u1f9e\u1f9f\u1fa8\u1fa9\u1faa\u1fab\u1fac\u1fad\u1fae\u1faf\u1fbc\u1fcc\u1ffc"
// // 	// ABCDEFGHIJKLMNOPQRSTUVWXYZ
// // 	cats.Lu = "\u00c0\u00c1\u00c2\u00c3\u00c4\u00c5\u00c6\u00c7\u00c8\u00c9\u00ca\u00cb\u00cc\u00cd\u00ce\u00cf\u00d0\u00d1\u00d2\u00d3\u00d4\u00d5\u00d6\u00d8\u00d9\u00da\u00db\u00dc\u00dd\u00de\u0100\u0102\u0104\u0106\u0108\u010a\u010c\u010e\u0110\u0112\u0114\u0116\u0118\u011a\u011c\u011e\u0120\u0122\u0124\u0126\u0128\u012a\u012c\u012e\u0130\u0132\u0134\u0136\u0139\u013b\u013d\u013f\u0141\u0143\u0145\u0147\u014a\u014c\u014e\u0150\u0152\u0154\u0156\u0158\u015a\u015c\u015e\u0160\u0162\u0164\u0166\u0168\u016a\u016c\u016e\u0170\u0172\u0174\u0176\u0178\u0179\u017b\u017d\u0181\u0182\u0184\u0186\u0187\u0189\u018a\u018b\u018e\u018f\u0190\u0191\u0193\u0194\u0196\u0197\u0198\u019c\u019d\u019f\u01a0\u01a2\u01a4\u01a6\u01a7\u01a9\u01ac\u01ae\u01af\u01b1\u01b2\u01b3\u01b5\u01b7\u01b8\u01bc\u01c4\u01c7\u01ca\u01cd\u01cf\u01d1\u01d3\u01d5\u01d7\u01d9\u01db\u01de\u01e0\u01e2\u01e4\u01e6\u01e8\u01ea\u01ec\u01ee\u01f1\u01f4\u01f6\u01f7\u01f8\u01fa\u01fc\u01fe\u0200\u0202\u0204\u0206\u0208\u020a\u020c\u020e\u0210\u0212\u0214\u0216\u0218\u021a\u021c\u021e\u0220\u0222\u0224\u0226\u0228\u022a\u022c\u022e\u0230\u0232\u023a\u023b\u023d\u023e\u0241\u0386\u0388\u0389\u038a\u038c\u038e\u038f\u0391\u0392\u0393\u0394\u0395\u0396\u0397\u0398\u0399\u039a\u039b\u039c\u039d\u039e\u039f\u03a0\u03a1\u03a3\u03a4\u03a5\u03a6\u03a7\u03a8\u03a9\u03aa\u03ab\u03d2\u03d3\u03d4\u03d8\u03da\u03dc\u03de\u03e0\u03e2\u03e4\u03e6\u03e8\u03ea\u03ec\u03ee\u03f4\u03f7\u03f9\u03fa\u03fd\u03fe\u03ff\u0400\u0401\u0402\u0403\u0404\u0405\u0406\u0407\u0408\u0409\u040a\u040b\u040c\u040d\u040e\u040f\u0410\u0411\u0412\u0413\u0414\u0415\u0416\u0417\u0418\u0419\u041a\u041b\u041c\u041d\u041e\u041f\u0420\u0421\u0422\u0423\u0424\u0425\u0426\u0427\u0428\u0429\u042a\u042b\u042c\u042d\u042e\u042f\u0460\u0462\u0464\u0466\u0468\u046a\u046c\u046e\u0470\u0472\u0474\u0476\u0478\u047a\u047c\u047e\u0480\u048a\u048c\u048e\u0490\u0492\u0494\u0496\u0498\u049a\u049c\u049e\u04a0\u04a2\u04a4\u04a6\u04a8\u04aa\u04ac\u04ae\u04b0\u04b2\u04b4\u04b6\u04b8\u04ba\u04bc\u04be\u04c0\u04c1\u04c3\u04c5\u04c7\u04c9\u04cb\u04cd\u04d0\u04d2\u04d4\u04d6\u04d8\u04da\u04dc\u04de\u04e0\u04e2\u04e4\u04e6\u04e8\u04ea\u04ec\u04ee\u04f0\u04f2\u04f4\u04f6\u04f8\u0500\u0502\u0504\u0506\u0508\u050a\u050c\u050e\u0531\u0532\u0533\u0534\u0535\u0536\u0537\u0538\u0539\u053a\u053b\u053c\u053d\u053e\u053f\u0540\u0541\u0542\u0543\u0544\u0545\u0546\u0547\u0548\u0549\u054a\u054b\u054c\u054d\u054e\u054f\u0550\u0551\u0552\u0553\u0554\u0555\u0556\u10a0\u10a1\u10a2\u10a3\u10a4\u10a5\u10a6\u10a7\u10a8\u10a9\u10aa\u10ab\u10ac\u10ad\u10ae\u10af\u10b0\u10b1\u10b2\u10b3\u10b4\u10b5\u10b6\u10b7\u10b8\u10b9\u10ba\u10bb\u10bc\u10bd\u10be\u10bf\u10c0\u10c1\u10c2\u10c3\u10c4\u10c5\u1e00\u1e02\u1e04\u1e06\u1e08\u1e0a\u1e0c\u1e0e\u1e10\u1e12\u1e14\u1e16\u1e18\u1e1a\u1e1c\u1e1e\u1e20\u1e22\u1e24\u1e26\u1e28\u1e2a\u1e2c\u1e2e\u1e30\u1e32\u1e34\u1e36\u1e38\u1e3a\u1e3c\u1e3e\u1e40\u1e42\u1e44\u1e46\u1e48\u1e4a\u1e4c\u1e4e\u1e50\u1e52\u1e54\u1e56\u1e58\u1e5a\u1e5c\u1e5e\u1e60\u1e62\u1e64\u1e66\u1e68\u1e6a\u1e6c\u1e6e\u1e70\u1e72\u1e74\u1e76\u1e78\u1e7a\u1e7c\u1e7e\u1e80\u1e82\u1e84\u1e86\u1e88\u1e8a\u1e8c\u1e8e\u1e90\u1e92\u1e94\u1ea0\u1ea2\u1ea4\u1ea6\u1ea8\u1eaa\u1eac\u1eae\u1eb0\u1eb2\u1eb4\u1eb6\u1eb8\u1eba\u1ebc\u1ebe\u1ec0\u1ec2\u1ec4\u1ec6\u1ec8\u1eca\u1ecc\u1ece\u1ed0\u1ed2\u1ed4\u1ed6\u1ed8\u1eda\u1edc\u1ede\u1ee0\u1ee2\u1ee4\u1ee6\u1ee8\u1eea\u1eec\u1eee\u1ef0\u1ef2\u1ef4\u1ef6\u1ef8\u1f08\u1f09\u1f0a\u1f0b\u1f0c\u1f0d\u1f0e\u1f0f\u1f18\u1f19\u1f1a\u1f1b\u1f1c\u1f1d\u1f28\u1f29\u1f2a\u1f2b\u1f2c\u1f2d\u1f2e\u1f2f\u1f38\u1f39\u1f3a\u1f3b\u1f3c\u1f3d\u1f3e\u1f3f\u1f48\u1f49\u1f4a\u1f4b\u1f4c\u1f4d\u1f59\u1f5b\u1f5d\u1f5f\u1f68\u1f69\u1f6a\u1f6b\u1f6c\u1f6d\u1f6e\u1f6f\u1fb8\u1fb9\u1fba\u1fbb\u1fc8\u1fc9\u1fca\u1fcb\u1fd8\u1fd9\u1fda\u1fdb\u1fe8\u1fe9\u1fea\u1feb\u1fec\u1ff8\u1ff9\u1ffa\u1ffb\u2102\u2107\u210b\u210c\u210d\u2110\u2111\u2112\u2115\u2119\u211a\u211b\u211c\u211d\u2124\u2126\u2128\u212a\u212b\u212c\u212d\u2130\u2131\u2133\u213e\u213f\u2145\u2c00\u2c01\u2c02\u2c03\u2c04\u2c05\u2c06\u2c07\u2c08\u2c09\u2c0a\u2c0b\u2c0c\u2c0d\u2c0e\u2c0f\u2c10\u2c11\u2c12\u2c13\u2c14\u2c15\u2c16\u2c17\u2c18\u2c19\u2c1a\u2c1b\u2c1c\u2c1d\u2c1e\u2c1f\u2c20\u2c21\u2c22\u2c23\u2c24\u2c25\u2c26\u2c27\u2c28\u2c29\u2c2a\u2c2b\u2c2c\u2c2d\u2c2e\u2c80\u2c82\u2c84\u2c86\u2c88\u2c8a\u2c8c\u2c8e\u2c90\u2c92\u2c94\u2c96\u2c98\u2c9a\u2c9c\u2c9e\u2ca0\u2ca2\u2ca4\u2ca6\u2ca8\u2caa\u2cac\u2cae\u2cb0\u2cb2\u2cb4\u2cb6\u2cb8\u2cba\u2cbc\u2cbe\u2cc0\u2cc2\u2cc4\u2cc6\u2cc8\u2cca\u2ccc\u2cce\u2cd0\u2cd2\u2cd4\u2cd6\u2cd8\u2cda\u2cdc\u2cde\u2ce0\u2ce2\uff21\uff22\uff23\uff24\uff25\uff26\uff27\uff28\uff29\uff2a\uff2b\uff2c\uff2d\uff2e\uff2f\uff30\uff31\uff32\uff33\uff34\uff35\uff36\uff37\uff38\uff39\uff3a"

// // 	cats.Mc = "\u0903\u093e\u093f\u0940\u0949\u094a\u094b\u094c\u0982\u0983\u09be\u09bf\u09c0\u09c7\u09c8\u09cb\u09cc\u09d7\u0a03\u0a3e\u0a3f\u0a40\u0a83\u0abe\u0abf\u0ac0\u0ac9\u0acb\u0acc\u0b02\u0b03\u0b3e\u0b40\u0b47\u0b48\u0b4b\u0b4c\u0b57\u0bbe\u0bbf\u0bc1\u0bc2\u0bc6\u0bc7\u0bc8\u0bca\u0bcb\u0bcc\u0bd7\u0c01\u0c02\u0c03\u0c41\u0c42\u0c43\u0c44\u0c82\u0c83\u0cbe\u0cc0\u0cc1\u0cc2\u0cc3\u0cc4\u0cc7\u0cc8\u0cca\u0ccb\u0cd5\u0cd6\u0d02\u0d03\u0d3e\u0d3f\u0d40\u0d46\u0d47\u0d48\u0d4a\u0d4b\u0d4c\u0d57\u0d82\u0d83\u0dcf\u0dd0\u0dd1\u0dd8\u0dd9\u0dda\u0ddb\u0ddc\u0ddd\u0dde\u0ddf\u0df2\u0df3\u0f3e\u0f3f\u0f7f\u102c\u1031\u1038\u1056\u1057\u17b6\u17be\u17bf\u17c0\u17c1\u17c2\u17c3\u17c4\u17c5\u17c7\u17c8\u1923\u1924\u1925\u1926\u1929\u192a\u192b\u1930\u1931\u1933\u1934\u1935\u1936\u1937\u1938\u19b0\u19b1\u19b2\u19b3\u19b4\u19b5\u19b6\u19b7\u19b8\u19b9\u19ba\u19bb\u19bc\u19bd\u19be\u19bf\u19c0\u19c8\u19c9\u1a19\u1a1a\u1a1b\ua802\ua823\ua824\ua827"

// // 	cats.Me = "\u0488\u0489\u06de\u20dd\u20de\u20df\u20e0\u20e2\u20e3\u20e4"

// // 	cats.Mn = "\u0300\u0301\u0302\u0303\u0304\u0305\u0306\u0307\u0308\u0309\u030a\u030b\u030c\u030d\u030e\u030f\u0310\u0311\u0312\u0313\u0314\u0315\u0316\u0317\u0318\u0319\u031a\u031b\u031c\u031d\u031e\u031f\u0320\u0321\u0322\u0323\u0324\u0325\u0326\u0327\u0328\u0329\u032a\u032b\u032c\u032d\u032e\u032f\u0330\u0331\u0332\u0333\u0334\u0335\u0336\u0337\u0338\u0339\u033a\u033b\u033c\u033d\u033e\u033f\u0340\u0341\u0342\u0343\u0344\u0345\u0346\u0347\u0348\u0349\u034a\u034b\u034c\u034d\u034e\u034f\u0350\u0351\u0352\u0353\u0354\u0355\u0356\u0357\u0358\u0359\u035a\u035b\u035c\u035d\u035e\u035f\u0360\u0361\u0362\u0363\u0364\u0365\u0366\u0367\u0368\u0369\u036a\u036b\u036c\u036d\u036e\u036f\u0483\u0484\u0485\u0486\u0591\u0592\u0593\u0594\u0595\u0596\u0597\u0598\u0599\u059a\u059b\u059c\u059d\u059e\u059f\u05a0\u05a1\u05a2\u05a3\u05a4\u05a5\u05a6\u05a7\u05a8\u05a9\u05aa\u05ab\u05ac\u05ad\u05ae\u05af\u05b0\u05b1\u05b2\u05b3\u05b4\u05b5\u05b6\u05b7\u05b8\u05b9\u05bb\u05bc\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7\u0610\u0611\u0612\u0613\u0614\u0615\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0653\u0654\u0655\u0656\u0657\u0658\u0659\u065a\u065b\u065c\u065d\u065e\u0670\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06df\u06e0\u06e1\u06e2\u06e3\u06e4\u06e7\u06e8\u06ea\u06eb\u06ec\u06ed\u0711\u0730\u0731\u0732\u0733\u0734\u0735\u0736\u0737\u0738\u0739\u073a\u073b\u073c\u073d\u073e\u073f\u0740\u0741\u0742\u0743\u0744\u0745\u0746\u0747\u0748\u0749\u074a\u07a6\u07a7\u07a8\u07a9\u07aa\u07ab\u07ac\u07ad\u07ae\u07af\u07b0\u0901\u0902\u093c\u0941\u0942\u0943\u0944\u0945\u0946\u0947\u0948\u094d\u0951\u0952\u0953\u0954\u0962\u0963\u0981\u09bc\u09c1\u09c2\u09c3\u09c4\u09cd\u09e2\u09e3\u0a01\u0a02\u0a3c\u0a41\u0a42\u0a47\u0a48\u0a4b\u0a4c\u0a4d\u0a70\u0a71\u0a81\u0a82\u0abc\u0ac1\u0ac2\u0ac3\u0ac4\u0ac5\u0ac7\u0ac8\u0acd\u0ae2\u0ae3\u0b01\u0b3c\u0b3f\u0b41\u0b42\u0b43\u0b4d\u0b56\u0b82\u0bc0\u0bcd\u0c3e\u0c3f\u0c40\u0c46\u0c47\u0c48\u0c4a\u0c4b\u0c4c\u0c4d\u0c55\u0c56\u0cbc\u0cbf\u0cc6\u0ccc\u0ccd\u0d41\u0d42\u0d43\u0d4d\u0dca\u0dd2\u0dd3\u0dd4\u0dd6\u0e31\u0e34\u0e35\u0e36\u0e37\u0e38\u0e39\u0e3a\u0e47\u0e48\u0e49\u0e4a\u0e4b\u0e4c\u0e4d\u0e4e\u0eb1\u0eb4\u0eb5\u0eb6\u0eb7\u0eb8\u0eb9\u0ebb\u0ebc\u0ec8\u0ec9\u0eca\u0ecb\u0ecc\u0ecd\u0f18\u0f19\u0f35\u0f37\u0f39\u0f71\u0f72\u0f73\u0f74\u0f75\u0f76\u0f77\u0f78\u0f79\u0f7a\u0f7b\u0f7c\u0f7d\u0f7e\u0f80\u0f81\u0f82\u0f83\u0f84\u0f86\u0f87\u0f90\u0f91\u0f92\u0f93\u0f94\u0f95\u0f96\u0f97\u0f99\u0f9a\u0f9b\u0f9c\u0f9d\u0f9e\u0f9f\u0fa0\u0fa1\u0fa2\u0fa3\u0fa4\u0fa5\u0fa6\u0fa7\u0fa8\u0fa9\u0faa\u0fab\u0fac\u0fad\u0fae\u0faf\u0fb0\u0fb1\u0fb2\u0fb3\u0fb4\u0fb5\u0fb6\u0fb7\u0fb8\u0fb9\u0fba\u0fbb\u0fbc\u0fc6\u102d\u102e\u102f\u1030\u1032\u1036\u1037\u1039\u1058\u1059\u135f\u1712\u1713\u1714\u1732\u1733\u1734\u1752\u1753\u1772\u1773\u17b7\u17b8\u17b9\u17ba\u17bb\u17bc\u17bd\u17c6\u17c9\u17ca\u17cb\u17cc\u17cd\u17ce\u17cf\u17d0\u17d1\u17d2\u17d3\u17dd\u180b\u180c\u180d\u18a9\u1920\u1921\u1922\u1927\u1928\u1932\u1939\u193a\u193b\u1a17\u1a18\u1dc0\u1dc1\u1dc2\u1dc3\u20d0\u20d1\u20d2\u20d3\u20d4\u20d5\u20d6\u20d7\u20d8\u20d9\u20da\u20db\u20dc\u20e1\u20e5\u20e6\u20e7\u20e8\u20e9\u20ea\u20eb\u302a\u302b\u302c\u302d\u302e\u302f\u3099\u309a\ua806\ua80b\ua825\ua826\ufb1e\ufe00\ufe01\ufe02\ufe03\ufe04\ufe05\ufe06\ufe07\ufe08\ufe09\ufe0a\ufe0b\ufe0c\ufe0d\ufe0e\ufe0f\ufe20\ufe21\ufe22\ufe23"
// // 	// 0123456789
// // 	cats.Nd = "\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669\u06f0\u06f1\u06f2\u06f3\u06f4\u06f5\u06f6\u06f7\u06f8\u06f9\u0966\u0967\u0968\u0969\u096a\u096b\u096c\u096d\u096e\u096f\u09e6\u09e7\u09e8\u09e9\u09ea\u09eb\u09ec\u09ed\u09ee\u09ef\u0a66\u0a67\u0a68\u0a69\u0a6a\u0a6b\u0a6c\u0a6d\u0a6e\u0a6f\u0ae6\u0ae7\u0ae8\u0ae9\u0aea\u0aeb\u0aec\u0aed\u0aee\u0aef\u0b66\u0b67\u0b68\u0b69\u0b6a\u0b6b\u0b6c\u0b6d\u0b6e\u0b6f\u0be6\u0be7\u0be8\u0be9\u0bea\u0beb\u0bec\u0bed\u0bee\u0bef\u0c66\u0c67\u0c68\u0c69\u0c6a\u0c6b\u0c6c\u0c6d\u0c6e\u0c6f\u0ce6\u0ce7\u0ce8\u0ce9\u0cea\u0ceb\u0cec\u0ced\u0cee\u0cef\u0d66\u0d67\u0d68\u0d69\u0d6a\u0d6b\u0d6c\u0d6d\u0d6e\u0d6f\u0e50\u0e51\u0e52\u0e53\u0e54\u0e55\u0e56\u0e57\u0e58\u0e59\u0ed0\u0ed1\u0ed2\u0ed3\u0ed4\u0ed5\u0ed6\u0ed7\u0ed8\u0ed9\u0f20\u0f21\u0f22\u0f23\u0f24\u0f25\u0f26\u0f27\u0f28\u0f29\u1040\u1041\u1042\u1043\u1044\u1045\u1046\u1047\u1048\u1049\u17e0\u17e1\u17e2\u17e3\u17e4\u17e5\u17e6\u17e7\u17e8\u17e9\u1810\u1811\u1812\u1813\u1814\u1815\u1816\u1817\u1818\u1819\u1946\u1947\u1948\u1949\u194a\u194b\u194c\u194d\u194e\u194f\u19d0\u19d1\u19d2\u19d3\u19d4\u19d5\u19d6\u19d7\u19d8\u19d9\uff10\uff11\uff12\uff13\uff14\uff15\uff16\uff17\uff18\uff19"

// // 	cats.Nl = "\u16ee\u16ef\u16f0\u2160\u2161\u2162\u2163\u2164\u2165\u2166\u2167\u2168\u2169\u216a\u216b\u216c\u216d\u216e\u216f\u2170\u2171\u2172\u2173\u2174\u2175\u2176\u2177\u2178\u2179\u217a\u217b\u217c\u217d\u217e\u217f\u2180\u2181\u2182\u2183\u3007\u3021\u3022\u3023\u3024\u3025\u3026\u3027\u3028\u3029\u3038\u3039\u303a"

// // 	cats.No = "\u00b2\u00b3\u00b9\u00bc\u00bd\u00be\u09f4\u09f5\u09f6\u09f7\u09f8\u09f9\u0bf0\u0bf1\u0bf2\u0f2a\u0f2b\u0f2c\u0f2d\u0f2e\u0f2f\u0f30\u0f31\u0f32\u0f33\u1369\u136a\u136b\u136c\u136d\u136e\u136f\u1370\u1371\u1372\u1373\u1374\u1375\u1376\u1377\u1378\u1379\u137a\u137b\u137c\u17f0\u17f1\u17f2\u17f3\u17f4\u17f5\u17f6\u17f7\u17f8\u17f9\u2070\u2074\u2075\u2076\u2077\u2078\u2079\u2080\u2081\u2082\u2083\u2084\u2085\u2086\u2087\u2088\u2089\u2153\u2154\u2155\u2156\u2157\u2158\u2159\u215a\u215b\u215c\u215d\u215e\u215f\u2460\u2461\u2462\u2463\u2464\u2465\u2466\u2467\u2468\u2469\u246a\u246b\u246c\u246d\u246e\u246f\u2470\u2471\u2472\u2473\u2474\u2475\u2476\u2477\u2478\u2479\u247a\u247b\u247c\u247d\u247e\u247f\u2480\u2481\u2482\u2483\u2484\u2485\u2486\u2487\u2488\u2489\u248a\u248b\u248c\u248d\u248e\u248f\u2490\u2491\u2492\u2493\u2494\u2495\u2496\u2497\u2498\u2499\u249a\u249b\u24ea\u24eb\u24ec\u24ed\u24ee\u24ef\u24f0\u24f1\u24f2\u24f3\u24f4\u24f5\u24f6\u24f7\u24f8\u24f9\u24fa\u24fb\u24fc\u24fd\u24fe\u24ff\u2776\u2777\u2778\u2779\u277a\u277b\u277c\u277d\u277e\u277f\u2780\u2781\u2782\u2783\u2784\u2785\u2786\u2787\u2788\u2789\u278a\u278b\u278c\u278d\u278e\u278f\u2790\u2791\u2792\u2793\u2cfd\u3192\u3193\u3194\u3195\u3220\u3221\u3222\u3223\u3224\u3225\u3226\u3227\u3228\u3229\u3251\u3252\u3253\u3254\u3255\u3256\u3257\u3258\u3259\u325a\u325b\u325c\u325d\u325e\u325f\u3280\u3281\u3282\u3283\u3284\u3285\u3286\u3287\u3288\u3289\u32b1\u32b2\u32b3\u32b4\u32b5\u32b6\u32b7\u32b8\u32b9\u32ba\u32bb\u32bc\u32bd\u32be\u32bf"
// //     // _
// // 	cats.Pc = "\u203f\u2040\u2054\ufe33\ufe34\ufe4d\ufe4e\ufe4f\uff3f"
// //     // -
// // 	cats.Pd = "\u058a\u1806\u2010\u2011\u2012\u2013\u2014\u2015\u2e17\u301c\u3030\u30a0\ufe31\ufe32\ufe58\ufe63\uff0d"
// // 	// )]}
// // 	cats.Pe = "\u0f3b\u0f3d\u169c\u2046\u207e\u208e\u232a\u23b5\u2769\u276b\u276d\u276f\u2771\u2773\u2775\u27c6\u27e7\u27e9\u27eb\u2984\u2986\u2988\u298a\u298c\u298e\u2990\u2992\u2994\u2996\u2998\u29d9\u29db\u29fd\u3009\u300b\u300d\u300f\u3011\u3015\u3017\u3019\u301b\u301e\u301f\ufd3f\ufe18\ufe36\ufe38\ufe3a\ufe3c\ufe3e\ufe40\ufe42\ufe44\ufe48\ufe5a\ufe5c\ufe5e\uff09\uff3d\uff5d\uff60\uff63"

// // 	cats.Pf = "\u00bb\u2019\u201d\u203a\u2e03\u2e05\u2e0a\u2e0d\u2e1d"

// // 	cats.Pi = "\u00ab\u2018\u201b\u201c\u201f\u2039\u2e02\u2e04\u2e09\u2e0c\u2e1c"
// // 	// !\"#%&'*,./:;?@\\
// // 	cats.Po = "\u00a1\u00b7\u00bf\u037e\u0387\u055a\u055b\u055c\u055d\u055e\u055f\u0589\u05be\u05c0\u05c3\u05c6\u05f3\u05f4\u060c\u060d\u061b\u061e\u061f\u066a\u066b\u066c\u066d\u06d4\u0700\u0701\u0702\u0703\u0704\u0705\u0706\u0707\u0708\u0709\u070a\u070b\u070c\u070d\u0964\u0965\u0970\u0df4\u0e4f\u0e5a\u0e5b\u0f04\u0f05\u0f06\u0f07\u0f08\u0f09\u0f0a\u0f0b\u0f0c\u0f0d\u0f0e\u0f0f\u0f10\u0f11\u0f12\u0f85\u0fd0\u0fd1\u104a\u104b\u104c\u104d\u104e\u104f\u10fb\u1361\u1362\u1363\u1364\u1365\u1366\u1367\u1368\u166d\u166e\u16eb\u16ec\u16ed\u1735\u1736\u17d4\u17d5\u17d6\u17d8\u17d9\u17da\u1800\u1801\u1802\u1803\u1804\u1805\u1807\u1808\u1809\u180a\u1944\u1945\u19de\u19df\u1a1e\u1a1f\u2016\u2017\u2020\u2021\u2022\u2023\u2024\u2025\u2026\u2027\u2030\u2031\u2032\u2033\u2034\u2035\u2036\u2037\u2038\u203b\u203c\u203d\u203e\u2041\u2042\u2043\u2047\u2048\u2049\u204a\u204b\u204c\u204d\u204e\u204f\u2050\u2051\u2053\u2055\u2056\u2057\u2058\u2059\u205a\u205b\u205c\u205d\u205e\u23b6\u2cf9\u2cfa\u2cfb\u2cfc\u2cfe\u2cff\u2e00\u2e01\u2e06\u2e07\u2e08\u2e0b\u2e0e\u2e0f\u2e10\u2e11\u2e12\u2e13\u2e14\u2e15\u2e16\u3001\u3002\u3003\u303d\u30fb\ufe10\ufe11\ufe12\ufe13\ufe14\ufe15\ufe16\ufe19\ufe30\ufe45\ufe46\ufe49\ufe4a\ufe4b\ufe4c\ufe50\ufe51\ufe52\ufe54\ufe55\ufe56\ufe57\ufe5f\ufe60\ufe61\ufe68\ufe6a\ufe6b\uff01\uff02\uff03\uff05\uff06\uff07\uff0a\uff0c\uff0e\uff0f\uff1a\uff1b\uff1f\uff20\uff3c\uff61\uff64\uff65"
// //     // ([{
// // 	cats.Ps = "\u0f3a\u0f3c\u169b\u201a\u201e\u2045\u207d\u208d\u2329\u23b4\u2768\u276a\u276c\u276e\u2770\u2772\u2774\u27c5\u27e6\u27e8\u27ea\u2983\u2985\u2987\u2989\u298b\u298d\u298f\u2991\u2993\u2995\u2997\u29d8\u29da\u29fc\u3008\u300a\u300c\u300e\u3010\u3014\u3016\u3018\u301a\u301d\ufd3e\ufe17\ufe35\ufe37\ufe39\ufe3b\ufe3d\ufe3f\ufe41\ufe43\ufe47\ufe59\ufe5b\ufe5d\uff08\uff3b\uff5b\uff5f\uff62"
// //     // \$
// // 	cats.Sc = "\u00a2\u00a3\u00a4\u00a5\u060b\u09f2\u09f3\u0af1\u0bf9\u0e3f\u17db\u20a0\u20a1\u20a2\u20a3\u20a4\u20a5\u20a6\u20a7\u20a8\u20a9\u20aa\u20ab\u20ac\u20ad\u20ae\u20af\u20b0\u20b1\u20b2\u20b3\u20b4\u20b5\ufdfc\ufe69\uff04\uffe0\uffe1\uffe5\uffe6"
// // 	// ^`
// // 	cats.Sk = "\u00a8\u00af\u00b4\u00b8\u02c2\u02c3\u02c4\u02c5\u02d2\u02d3\u02d4\u02d5\u02d6\u02d7\u02d8\u02d9\u02da\u02db\u02dc\u02dd\u02de\u02df\u02e5\u02e6\u02e7\u02e8\u02e9\u02ea\u02eb\u02ec\u02ed\u02ef\u02f0\u02f1\u02f2\u02f3\u02f4\u02f5\u02f6\u02f7\u02f8\u02f9\u02fa\u02fb\u02fc\u02fd\u02fe\u02ff\u0374\u0375\u0384\u0385\u1fbd\u1fbf\u1fc0\u1fc1\u1fcd\u1fce\u1fcf\u1fdd\u1fde\u1fdf\u1fed\u1fee\u1fef\u1ffd\u1ffe\u309b\u309c\ua700\ua701\ua702\ua703\ua704\ua705\ua706\ua707\ua708\ua709\ua70a\ua70b\ua70c\ua70d\ua70e\ua70f\ua710\ua711\ua712\ua713\ua714\ua715\ua716\uff3e\uff40\uffe3"

// // 	cats.Zl = "\u2028"

// // 	cats.Zp = "\u2029"
// // 	// " "
// // 	cats.Zs = "\u00a0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000"
// // 	return cats?."${key}" ?: cats?.Nd
// // }















// import com.sap.gateway.ip.core.customdev.util.Message
// // import om.sap.it.api.securestore.* 
// // import com.sap.it.api.keystore.*

// def Message processData(Message message) {
//     def resultApi = credentialApi(message)
//     def resultReflect = credentialApiReflection(message)
//     def results = ("-"*40) + "\n\n\t-----\tAPI Results\t-----\n${resultApi}\n"  + ("-"*40)
//         + ("-"*40) + "\n\n\t-----\tAPI Reflection Results\t-----\n${resultReflect}\n" + ("-"*40)
//     message.setBody(results)
//     message.setHeader("Content-Type", "text/plain")
//     message
// }

// def String credentialApi(Message msg) {
// 	def log = new StringBuffer()
// 	if (isInvalidRequest(msg, log)) return log.toString()
	
//     log << "\ncom.sap.it.api.ITApiFactory:\t${com.sap.it.api.ITApiFactory}"
// 	com.sap.it.api.securestore.SecureStoreService sss = com.sap.it.api.ITApiFactory.getApi(com.sap.it.api.securestore.SecureStoreService.class, null)
// 	log << "\ncom.sap.it.api.securestore.SecureStoreService:\t$sss"
// 	log << "\n\nCredential: $msg.headers.Credential"
// 	com.sap.it.api.securestore.UserCredential uc = sss.getUserCredential(msg.headers.Credential as String)
// 	log << "\ncom.sap.it.api.securestore.UserCredential:\t$uc"
// 	log << "\nUserCredential properties:\t${uc.credentialProperties}"
// 	log << "\nUserCredential username:\t${uc.username}"
// 	log << "\nUserCredential password:\t${uc.password}"
// 	log << "\n"+"-"*40

// 	com.sap.it.api.keystore.KeystoreService ks = com.sap.it.api.ITApiFactory.getApi(com.sap.it.api.keystore.KeystoreService.class, null)
// 	log << "\n\ncom.sap.it.api.keystore.KeystoreService:\t$ks"
// 	log << "\ncom.sap.it.api.keystore.KeystoreService javax.net.ssl.KeyManager:\t${ks.keyManager}"
// 	log << "\ncom.sap.it.api.keystore.KeystoreService javax.net.ssl.KeyManagers:\t${ks.keyManagers}"
// 	log << "\ncom.sap.it.api.keystore.KeystoreService javax.net.ssl.TrustManager:\t${ks.trustManager}"
// 	log << "\ncom.sap.it.api.keystore.KeystoreService javax.net.ssl.TrustManagers:\t${ks.trustManagers}"
	
// 	if (msg.headers.Keystore) {
// 		log << "\n\nKeystore: $msg.headers.Keystore"
// 		log << "\n"+"-"*40
// 	}
// 	log.toString()                              
// }

// def String credentialApiReflection(Message msg) {
// 	def log = new StringBuffer()
// 	if (isInvalidRequest(msg, log)) return log.toString()
	
//     Class itApiFactory = Class.forName("com.sap.it.api.ITApiFactory")
// 	Class secureStoreService = Class.forName("com.sap.it.api.securestore.SecureStoreService")
// 	Class keystoreService = Class.forName("com.sap.it.api.keystore.KeystoreService")
// 	Class userCredential = Class.forName("com.sap.it.api.securestore.UserCredential")
	
// 	log << "\nclass com.sap.it.api.ITApiFactory:\t$itApiFactory"
// 	log << "\nclass com.sap.it.api.securestore.SecureStoreService:\t$secureStoreService"
// 	log << "\nclass com.sap.it.api.keystore.KeystoreService:\t$keystoreService"
// 	log << "\nclass com.sap.it.api.securestore.UserCredential:\t$userCredential"

// 	def sss = itApiFactory.getApi(secureStoreService, null)
// 	log << "\ncom.sap.it.api.securestore.SecureStoreService:\t$sss"
// 	if (msg.headers.Credential) {
// 		log << "\n\nCredential: $msg.headers.Credential"
// 		def uc = sss.getUserCredential(msg.headers.Credential as String)
// 		log << "\ncom.sap.it.api.securestore.UserCredential:\t$uc"
// 		log << "\nUserCredential properties:\t${uc.credentialProperties}"
// 		log << "\nUserCredential username:\t${uc.username}"
// 		log << "\nUserCredential password:\t${uc.password}"
// 		log << "\n"+"-"*40
// 	}
// 	log.toString()                               
// }

// def boolean isInvalidRequest(Message msg, String log) {
// 	if (!msg.headers.Credential && !msg.headers.Keystore) {
// 		def err = "" 
// 			+ (!msg.headers.Credential ? "\nHeader `Credential` - got value  `${msg.headers.Credential}` instead." : "") 
// 			+ (!msg.headers.Keystore ? "\nHeader `Keystore` - got value  `${msg.headers.Keystore}` instead.\n" : "")
// 		log << "\n\nError - Missing Required Header. ${err}"
// 		log << "\n"+"-"*40
// 		msg.setHeader("CamelHttpCode", "404")
// 		msg.setBody(log as String)
// 		return true
// 	}
// 	return false
// }